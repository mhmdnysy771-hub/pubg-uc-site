const express=require("express"),path=require("path");
const app=express(),PORT=process.env.PORT||3000;
app.use(express.json());app.use(express.static(__dirname));
app.post("/api/order",async(req,res)=>{
 const {uc,email,pubgId}=req.body||{};
 if(!["60","325","660"].includes(String(uc))) return res.status(400).json({error:"بسته نامعتبر است."});
 if(!email||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:"ایمیل معتبر وارد کنید."});
 if(!pubgId||!/^\d{5,20}$/.test(String(pubgId))) return res.status(400).json({error:"آیدی PUBG معتبر وارد کنید."});
 const text=`سفارش جدید UC\nUC: ${uc}\nایمیل: ${email}\nPUBG ID: ${pubgId}`;
 if(process.env.ORDER_WEBHOOK_URL){try{let r=await fetch(process.env.ORDER_WEBHOOK_URL,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({text,uc,email,pubgId})});if(!r.ok)throw Error()}catch(e){return res.status(502).json({error:"اعلان ارسال نشد."})}}
 else console.log(text);
 res.json({ok:true});
});
app.listen(PORT,()=>console.log("Running on "+PORT));